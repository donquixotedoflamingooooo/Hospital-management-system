<?php
$servername = "localhost";
$username = "root"; 
$password = ""; 
$database = "hospital";

$conn = new mysqli($servername, $username, $password, $database);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = $_POST["name"];
    $age = $_POST["age"];
    $gender = $_POST["gender"];
    $medical = $_POST["medical"];

    $query = "INSERT INTO `details`(`name`, `age`, `gender`, `medical`) VALUES ('$name','$age','$gender','$medical')";
   $result = mysqli_query($conn, $query);
    if($result){
        echo"Data inserted into the database";
    }
    else{
        echo"task failed" . $conn->error;
    }
}
?> 