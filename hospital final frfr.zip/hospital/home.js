document.addEventListener("DOMContentLoaded", function() {
    var navLinks = document.querySelectorAll(".navbar a");
    for (var i = 0; i < navLinks.length; i++) {
        navLinks[i].onclick = function() {
            alert("You clicked on " + this.textContent);
        };
    }
});
