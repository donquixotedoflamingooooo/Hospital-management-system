document.addEventListener("DOMContentLoaded", function () {
    const loginForm = document.getElementById("adminLoginForm");
  
    if (loginForm) {
      loginForm.addEventListener("submit", function (event) {
        event.preventDefault();
  
        const username = document.getElementById("adminUsername").value;
        const password = document.getElementById("adminPassword").value;
  
        // Hardcoded admin credentials (Replace with secure authentication)
        const adminUsername = "admin";
        const adminPassword = "password123";
  
        if (username === adminUsername && password === adminPassword) {
          sessionStorage.setItem("adminLoggedIn", "true"); // Store admin session
          window.location.href = "details.html"; // Redirect to details page
        } else {
          document.getElementById("error-message").style.display = "block";
        }
      });
    }
  });
  