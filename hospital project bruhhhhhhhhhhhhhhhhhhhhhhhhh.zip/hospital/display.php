<?php
include 'connection.php';

$sql = "SELECT * FROM patientdetails";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        echo "<tr>
                <td>" . $row["name"] . "</td>
                <td>" . $row["age"] . "</td>
                <td>" . $row["gender"] . "</td>
                <td>" . $row["medical_condition"] . "</td>
                <td>
                    <button onclick='editPatient(" . $row["id"] . ")'>Edit</button>
                    <button onclick='deletePatient(" . $row["id"] . ")'>Delete</button>
                </td>
              </tr>";
    }
} else {
    echo "No records found";
}

$conn->close();
?>
