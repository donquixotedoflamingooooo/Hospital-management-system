<?php
$host = "localhost";
$user = "root";
$pass = "";
$db = "myDB";

$conn = new mysqli($host, $user, $pass, $db);

if ($conn->connect_error) {
    die("Connection error: " . $conn->connect_error);
} else {
    echo "Connected successfully.<br>";
}

$sql = "CREATE TABLE patientdetails (
    id INT(5) AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(30) NOT NULL,
    age INT(3) NOT NULL,
    gender varchar(1) NOT NULL,
    medical_condition VARCHAR(100) NOT NULL
)";

if ($conn->query($sql) === TRUE) {
    echo "Table created successfully.";
} else {
    echo "Error creating table: " . $conn->error;
}

$conn->close();
?>