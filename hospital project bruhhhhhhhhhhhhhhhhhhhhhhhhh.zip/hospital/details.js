function addPatient() {
  const name = document.getElementById('name').value.trim();
  const age = document.getElementById('age').value.trim();
  const gender = document.getElementById('gender').value;
  const condition = document.getElementById('condition').value.trim();

  if (name && age && gender && condition) {
    const table = document.getElementById('patientList').getElementsByTagName('tbody')[0];
    const row = table.insertRow();
    row.innerHTML = `<td>${name}</td><td>${age}</td><td>${gender}</td><td>${condition}</td>`;
    document.getElementById('patientForm').reset();
    alert('Patient added successfully!');
  } else {
    alert('Please fill in all fields.');
  }
}

function bookBed(bedType) {
  const availableSpan = document.getElementById(`${bedType.toLowerCase()}Available`);
  const occupiedSpan = document.getElementById(`${bedType.toLowerCase()}Occupied`);

  let available = parseInt(availableSpan.textContent);
  let occupied = parseInt(occupiedSpan.textContent);

  if (available > 0) {
    available--;
    occupied++;
    availableSpan.textContent = available;
    occupiedSpan.textContent = occupied;
    alert(`${bedType} bed booked successfully!`);
  } else {
    alert(`No ${bedType} beds available.`);
  }
}

if (sessionStorage.getItem("adminLoggedIn") !== "true") {
  window.location.href = "admin.html";
}

document.getElementById("logoutButton").addEventListener("click", function () {
  sessionStorage.removeItem("adminLoggedIn");
  window.location.href = "admin.html";
});
