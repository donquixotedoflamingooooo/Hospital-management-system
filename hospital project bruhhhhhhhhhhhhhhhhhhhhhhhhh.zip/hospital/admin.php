<?php
include 'connection.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = $_POST["name"];
    $age = $_POST["age"];
    $gender = $_POST["gender"];
    $medical_condition = $_POST["medical_condition"];

    
    $stmt = $conn->prepare("INSERT INTO patientdetails (name, age, gender, medical_condition) VALUES (?, ?, ?, ?)");
    
    if ($stmt === false) {
        die("Error in SQL preparation: " . $conn->error);
    }

   
    $stmt->bind_param("siss", $name, $age, $gender, $medical_condition);

   
    if ($stmt->execute()) {
        echo "Record inserted successfully!";
    } else {
        echo "Error inserting record: " . $stmt->error;
    }

    
    $stmt->close();
    $conn->close();
} else {
    echo "Invalid request method!";
}
?>


   