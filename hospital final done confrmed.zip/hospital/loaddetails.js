// Function to handle form submission
document.getElementById("patientForm").addEventListener("submit", function(event) {
    event.preventDefault();  // Prevent default form submission

    // Get the form values
    var name = document.getElementById("name").value;
    var age = document.getElementById("age").value;
    var gender = document.getElementById("gender").value;
    var medical_condition = document.getElementById("condition").value;

    // Send the data to the server (admin.php) using AJAX
    var xhr = new XMLHttpRequest();
    xhr.open("POST", "admin.php", true);
    xhr.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
    xhr.onload = function() {
        if (xhr.status == 200) {
            loadPatients();  // Reload patients data after insertion
        }
    };
    xhr.send("name=" + name + "&age=" + age + "&gender=" + gender + "&medical_condition=" + medical_condition);
});

// Function to load and display patient data
function loadPatients() {
    var xhr = new XMLHttpRequest();
    xhr.open("GET", "get_patients.php", true);
    xhr.onload = function() {
        if (xhr.status == 200) {
            document.querySelector("#patientList tbody").innerHTML = xhr.responseText;  // Display the fetched data
        }
    };
    xhr.send();
}

// Load patient data when the page loads
window.onload = loadPatients;
