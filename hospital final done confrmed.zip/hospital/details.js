let selectedRow = null;

    function addOrUpdatePatient() {
      const name = document.getElementById('name').value.trim();
      const age = document.getElementById('age').value.trim();
      const gender = document.getElementById('gender').value;
      const condition = document.getElementById('condition').value.trim();

      if (name && age && gender && condition) {
        if (selectedRow) {
          selectedRow.cells[0].textContent = name;
          selectedRow.cells[1].textContent = age;
          selectedRow.cells[2].textContent = gender;
          selectedRow.cells[3].textContent = condition;
          selectedRow = null;
        } else {
          const table = document.getElementById('patientList').getElementsByTagName('tbody')[0];
          const row = table.insertRow();
          row.innerHTML = `<td>${name}</td><td>${age}</td><td>${gender}</td><td>${condition}</td>
                           <td><button onclick="editPatient(this)">Update</button>
                               <button onclick="deletePatient(this)">Delete</button></td>`;
        }
        document.getElementById('patientForm').reset();
        alert('Patient added/updated successfully!');
      } else {
        alert('Please fill in all fields.');
      }
    }

    function editPatient(button) {
      selectedRow = button.parentElement.parentElement;
      document.getElementById('name').value = selectedRow.cells[0].textContent;
      document.getElementById('age').value = selectedRow.cells[1].textContent;
      document.getElementById('gender').value = selectedRow.cells[2].textContent;
      document.getElementById('condition').value = selectedRow.cells[3].textContent;
    }

    function deletePatient(button) {
      if (confirm('Are you sure you want to delete this patient?')) {
        const row = button.parentElement.parentElement;
        row.parentNode.removeChild(row);
        alert('Patient deleted successfully!');
      }
    }